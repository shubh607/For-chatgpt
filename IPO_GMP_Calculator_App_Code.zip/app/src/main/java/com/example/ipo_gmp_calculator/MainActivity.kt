package com.example.ipo_gmp_calculator

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val ipoPriceInput = findViewById<EditText>(R.id.ipoPrice)
        val gmpInput = findViewById<EditText>(R.id.gmp)
        val resultView = findViewById<TextView>(R.id.result)
        val calculateButton = findViewById<Button>(R.id.calculateBtn)

        calculateButton.setOnClickListener {
            val ipoPrice = ipoPriceInput.text.toString().toDoubleOrNull()
            val gmp = gmpInput.text.toString().toDoubleOrNull()

            if (ipoPrice != null && gmp != null) {
                val listingPrice = ipoPrice + gmp
                resultView.text = "📈 Expected Listing Price: ₹${"%.2f".format(listingPrice)}"
            } else {
                resultView.text = "❗ Please enter valid numbers."
            }
        }
    }
}